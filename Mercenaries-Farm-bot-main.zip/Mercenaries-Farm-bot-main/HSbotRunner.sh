python3.11 -m venv MFB
./MFB/bin/python -m pip install -r requirements_linux.txt
./MFB/bin/python main.py
