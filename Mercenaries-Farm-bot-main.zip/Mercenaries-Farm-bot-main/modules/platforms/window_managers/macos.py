# need somebody to test :
# https://github.com/asweigart/pyautogui/issues/279#issuecomment-1407463619
