from .factory import get_window_mgr_on_windows

__all__ = ["get_window_mgr_on_windows"]
